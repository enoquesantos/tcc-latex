package org.qtproject.qt5.android.bindings;

public class ActivityToApplication
{
    public static native void eventNotify(String eventName, String eventData);
}
