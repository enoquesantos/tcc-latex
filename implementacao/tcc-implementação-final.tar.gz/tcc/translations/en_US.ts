<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AboutPage</name>
    <message>
        <location filename="../plugins/About/AboutPage.qml" line="9"/>
        <source>About </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CameraCapture</name>
    <message>
        <location filename="../src/qml/CameraCapture.qml" line="7"/>
        <source>Capture new image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Datepicker</name>
    <message>
        <location filename="../src/qml/Datepicker.qml" line="107"/>
        <source>Previous year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/Datepicker.qml" line="156"/>
        <source>Next year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/Datepicker.qml" line="248"/>
        <source>CANCEL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/Datepicker.qml" line="256"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EulaAgreement</name>
    <message>
        <location filename="../src/qml/private/EulaAgreement.qml" line="10"/>
        <source>Terms of Use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/private/EulaAgreement.qml" line="46"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/private/EulaAgreement.qml" line="58"/>
        <source>NOT AGREE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/private/EulaAgreement.qml" line="60"/>
        <source>Warning!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/private/EulaAgreement.qml" line="60"/>
        <source>You need to read and accept the terms! Otherwise you will cannot use the application!!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/private/EulaAgreement.qml" line="65"/>
        <source>AGREE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Login</name>
    <message>
        <location filename="../plugins/Session/Login.qml" line="14"/>
        <location filename="../plugins/Session/Login.qml" line="18"/>
        <location filename="../plugins/Session/Login.qml" line="67"/>
        <location filename="../plugins/Session/Login.qml" line="69"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/Login.qml" line="14"/>
        <source>Login or Password is invalid. Check your credentials and try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/Login.qml" line="18"/>
        <source>A error occur in the server! Try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/Login.qml" line="49"/>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/Login.qml" line="57"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/Login.qml" line="64"/>
        <source>LOG IN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/Login.qml" line="67"/>
        <source>Please! Enter your login!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/Login.qml" line="69"/>
        <source>Please! Enter your password!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/Login.qml" line="79"/>
        <source>Retrieve password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Logout</name>
    <message>
        <location filename="../plugins/Session/Logout.qml" line="7"/>
        <source>Logout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/Logout.qml" line="29"/>
        <source>Good bye!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/Logout.qml" line="41"/>
        <source>Are sure you want to quit the app?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/Logout.qml" line="48"/>
        <source>Yes! exit now</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LostPassword</name>
    <message>
        <location filename="../plugins/Session/LostPassword.qml" line="15"/>
        <location filename="../plugins/Session/LostPassword.qml" line="19"/>
        <location filename="../plugins/Session/LostPassword.qml" line="51"/>
        <location filename="../plugins/Session/LostPassword.qml" line="53"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/LostPassword.qml" line="15"/>
        <source>Email not found. try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/LostPassword.qml" line="17"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/LostPassword.qml" line="17"/>
        <source>Your password was sent for your email!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/LostPassword.qml" line="19"/>
        <source>An error occur in the server! Try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/LostPassword.qml" line="41"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/LostPassword.qml" line="47"/>
        <source>Submit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/LostPassword.qml" line="51"/>
        <source>Enter your Email!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/LostPassword.qml" line="53"/>
        <source>Enter a valid Email!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page1</name>
    <message>
        <location filename="../plugins/Examples/Page1.qml" line="10"/>
        <location filename="../plugins/Pages/Page1.qml" line="10"/>
        <source>Page 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page2</name>
    <message>
        <location filename="../plugins/Pages/Page2.qml" line="10"/>
        <source>Page 2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page3</name>
    <message>
        <location filename="../plugins/Pages/Page3.qml" line="11"/>
        <source>Welcome!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Pages/Page3.qml" line="29"/>
        <source>Show in grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Pages/Page3.qml" line="33"/>
        <source>Reload list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page4</name>
    <message>
        <location filename="../plugins/Pages/Page4.qml" line="9"/>
        <source>Page 4</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page5</name>
    <message>
        <location filename="../plugins/Pages/Page5.qml" line="9"/>
        <source>Page 5</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page6</name>
    <message>
        <location filename="../plugins/Pages/Page6.qml" line="9"/>
        <source>Page 6</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhotoSelection</name>
    <message>
        <location filename="../src/qml/PhotoSelection.qml" line="59"/>
        <source>Choose a option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/PhotoSelection.qml" line="70"/>
        <source>Open the camera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/PhotoSelection.qml" line="76"/>
        <source>Choose from gallery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/PhotoSelection.qml" line="82"/>
        <source>Remove current image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProfileEdit</name>
    <message>
        <location filename="../plugins/Session/ProfileEdit.qml" line="9"/>
        <source>Edit my profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/ProfileEdit.qml" line="25"/>
        <location filename="../plugins/Session/ProfileEdit.qml" line="28"/>
        <location filename="../plugins/Session/ProfileEdit.qml" line="31"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/ProfileEdit.qml" line="25"/>
        <source>The email field is blank!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/ProfileEdit.qml" line="28"/>
        <source>The email is not valid!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/ProfileEdit.qml" line="31"/>
        <source>The passwords does not match!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/ProfileEdit.qml" line="35"/>
        <source>Updating profile...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/ProfileEdit.qml" line="93"/>
        <source>To update your password, enter the new password&apos;s in the fields below. Otherwise, leave the fields empty. We recommend that you create a strong password with characters, letters and numbers!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/ProfileEdit.qml" line="104"/>
        <source>youremail@example.com</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/ProfileEdit.qml" line="114"/>
        <source>Set the new password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/ProfileEdit.qml" line="123"/>
        <source>Confirm the new password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProfileView</name>
    <message>
        <location filename="../plugins/Session/ProfileView.qml" line="9"/>
        <source>My profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/ProfileView.qml" line="27"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../plugins/Session/ProfileView.qml" line="32"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RequestHttp</name>
    <message>
        <location filename="../src/qml/RequestHttp.qml" line="15"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/RequestHttp.qml" line="15"/>
        <location filename="../src/qml/RequestHttp.qml" line="17"/>
        <source>Cannot connect to server!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimePicker</name>
    <message>
        <location filename="../src/qml/TimePicker.qml" line="34"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolBarSearch</name>
    <message>
        <location filename="../src/qml/private/ToolBarSearch.qml" line="15"/>
        <source> tap to search...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../src/qml/private/main.qml" line="13"/>
        <source>Welcome </source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
